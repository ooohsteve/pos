## LAN Proof-of-Stake (PoS) Blockchain – Node.js

This is a **minimal offline (LAN-only)** Proof-of-Stake blockchain prototype built with Node.js.  
Each node runs an HTTP API for control and a WebSocket-based P2P layer to sync the chain with peers on the same network.

### 1. Install dependencies

From `E:\Workspace\pos`:

```bash
npm install
```

If PowerShell blocks `npm.ps1`, either:
- Run `npm` from `cmd.exe`, or
- Unblock it with: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

### 2. Environment variables per node

Each node uses:

- **`HTTP_PORT`**: REST API port (default `3001`)
- **`P2P_PORT`**: WebSocket P2P port (default `6001`)
- **`PEERS`**: comma-separated list of `ws://IP:port` of other nodes

Example (Node 1 on machine A):

```bash
set HTTP_PORT=3001
set P2P_PORT=6001
set PEERS=ws://192.168.0.102:6002
npm start
```

Node 2 on machine B:

```bash
set HTTP_PORT=3002
set P2P_PORT=6002
set PEERS=ws://192.168.0.101:6001
npm start
```

Use the actual LAN IPs of the machines.

### 3. HTTP API

All examples assume `HTTP_PORT=3001` on the node you call.

- **Get node address**

  ```bash
  curl http://localhost:3001/address
  ```

- **Get balance & staked**

  ```bash
  curl http://localhost:3001/balance
  ```

- **View chain**

  ```bash
  curl http://localhost:3001/chain
  ```

- **Stake tokens** (enable PoS for this node)

  ```bash
  curl -X POST http://localhost:3001/stake ^
    -H "Content-Type: application/json" ^
    -d "{\"amount\": 50}"
  ```

- **Send transaction**

  ```bash
  curl -X POST http://localhost:3001/transaction ^
    -H "Content-Type: application/json" ^
    -d "{\"to\": \"OTHER_NODE_ADDRESS\", \"amount\": 10}"
  ```

- **Produce block (PoS)**

  Only the node randomly selected as validator (proportional to stake) can succeed:

  ```bash
  curl -X POST http://localhost:3001/produce-block
  ```

### 4. How it works (high level)

- **Blockchain**: simple chain of blocks storing transactions and the global stake map.
- **Wallet**: each node has one local wallet with an address, balance, and staked amount.
- **PoS selection**: validator is chosen randomly but weighted by stake amounts.
- **P2P**: nodes use WebSockets to broadcast new blocks, transactions, and staking info across the LAN.

This is a teaching/demo implementation and **not** secure for real money.


