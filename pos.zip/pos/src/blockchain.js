const crypto = require('crypto');
const vm = require('vm');

class Block {
  constructor({ index, timestamp, previousHash, data, validator, hash }) {
    this.index = index;
    this.timestamp = timestamp;
    this.previousHash = previousHash;
    this.data = data; // { transactions, stakes }
    this.validator = validator;
    this.hash = hash || Block.calculateHash(index, timestamp, previousHash, data, validator);
  }

  static calculateHash(index, timestamp, previousHash, data, validator) {
    const payload = JSON.stringify({ index, timestamp, previousHash, data, validator });
    return crypto.createHash('sha256').update(payload).digest('hex');
  }
}

class Blockchain {
  constructor() {
    this.chain = [this.createGenesisBlock()];
    this.pendingTransactions = [];
    this.stakes = {}; // address -> amount
    this.contracts = {}; // address -> { code, storage }
  }

  createGenesisBlock() {
    return new Block({
      index: 0,
      timestamp: Date.now(),
      previousHash: '0',
      data: { transactions: [], stakes: {}, contracts: {} },
      validator: 'genesis',
    });
  }

  getLastBlock() {
    return this.chain[this.chain.length - 1];
  }

  addTransaction(tx) {
    this.pendingTransactions.push(tx);
  }

  addStake(address, amount) {
    if (!this.stakes[address]) this.stakes[address] = 0;
    this.stakes[address] += amount;
  }

  getTotalStake() {
    return Object.values(this.stakes).reduce((a, b) => a + b, 0);
  }

  getContractState(address) {
    const c = this.contracts[address];
    return c ? c.storage : null;
  }

  selectValidator() {
    const totalStake = this.getTotalStake();
    const entries = Object.entries(this.stakes).filter(([, stake]) => stake > 0);
    if (totalStake === 0 || entries.length === 0) return null;

    const seed = this.getLastBlock().hash + Date.now().toString();
    const rand = parseInt(crypto.createHash('sha256').update(seed).digest('hex').slice(0, 8), 16);
    let pick = rand % totalStake;

    for (const [address, stake] of entries) {
      if (pick < stake) return address;
      pick -= stake;
    }
    return entries[entries.length - 1][0];
  }

  createBlock(validatorAddress) {
    const lastBlock = this.getLastBlock();

    // Apply pending transactions to current state to compute next state
    const { stakes, contracts } = applyTransactionsOnState(
      this.stakes,
      this.contracts,
      this.pendingTransactions,
      validatorAddress,
    );

    const blockData = {
      transactions: this.pendingTransactions,
      stakes,
      contracts,
    };
    const newBlock = new Block({
      index: lastBlock.index + 1,
      timestamp: Date.now(),
      previousHash: lastBlock.hash,
      data: blockData,
      validator: validatorAddress,
    });
    return newBlock;
  }

  addBlock(block) {
    const lastBlock = this.getLastBlock();
    if (block.previousHash !== lastBlock.hash) return false;
    if (block.index !== lastBlock.index + 1) return false;
    const checkHash = Block.calculateHash(
      block.index,
      block.timestamp,
      block.previousHash,
      block.data,
      block.validator,
    );
    if (checkHash !== block.hash) return false;

    // Verify that the state encoded in the block matches deterministic execution
    let nextState;
    try {
      nextState = applyTransactionsOnState(
        this.stakes,
        this.contracts,
        block.data.transactions || [],
        block.validator,
      );
    } catch (e) {
      // Invalid contract execution, reject block
      return false;
    }

    const sameStakes = JSON.stringify(nextState.stakes) === JSON.stringify(block.data.stakes || {});
    const sameContracts = JSON.stringify(nextState.contracts) === JSON.stringify(block.data.contracts || {});
    if (!sameStakes || !sameContracts) return false;

    this.chain.push(block);
    this.pendingTransactions = [];
    this.stakes = nextState.stakes;
    this.contracts = nextState.contracts;
    return true;
  }

  isValidChain(chain) {
    if (!Array.isArray(chain) || chain.length === 0) return false;
    for (let i = 1; i < chain.length; i++) {
      const prev = chain[i - 1];
      const curr = chain[i];
      if (curr.previousHash !== prev.hash) return false;
      const checkHash = Block.calculateHash(
        curr.index,
        curr.timestamp,
        curr.previousHash,
        curr.data,
        curr.validator,
      );
      if (checkHash !== curr.hash) return false;
    }
    return true;
  }

  replaceChain(newChain) {
    if (newChain.length <= this.chain.length) return false;
    if (!this.isValidChain(newChain)) return false;
    this.chain = newChain;
    const last = this.getLastBlock();
    this.stakes = (last.data && last.data.stakes) || {};
    this.contracts = (last.data && last.data.contracts) || {};
    this.pendingTransactions = [];
    return true;
  }
}

// --- Smart contract execution helpers ---

function applyTransactionsOnState(prevStakes, prevContracts, transactions, validatorAddress) {
  const stakes = { ...prevStakes };
  const contracts = {};

  // Deep-ish clone contracts (code + shallow storage clone)
  for (const [addr, c] of Object.entries(prevContracts)) {
    contracts[addr] = {
      code: c.code,
      storage: { ...(c.storage || {}) },
    };
  }

  for (const tx of transactions || []) {
    if (!tx || !tx.type) continue;
    switch (tx.type) {
      case 'stake': {
        if (!stakes[tx.from]) stakes[tx.from] = 0;
        stakes[tx.from] += tx.amount;
        break;
      }
      case 'contract_deploy': {
        const address =
          tx.address ||
          crypto
            .createHash('sha256')
            .update(`${tx.from}:${tx.timestamp}:${tx.code || ''}`)
            .digest('hex')
            .slice(0, 40);

        if (!tx.code || typeof tx.code !== 'string') {
          throw new Error('Invalid contract code');
        }

        let storage = {};
        // Run optional init(state, args, ctx)
        storage = runContractMethod(tx.code, storage, 'init', tx.initArgs || {}, {
          sender: tx.from,
          validator: validatorAddress,
          contractAddress: address,
        });

        contracts[address] = {
          code: tx.code,
          storage,
        };
        break;
      }
      case 'contract_call': {
        const address = tx.to;
        const method = tx.method;
        if (!address || !method) {
          throw new Error('Invalid contract call');
        }
        const contract = contracts[address];
        if (!contract) {
          throw new Error('Contract not found');
        }
        const newStorage = runContractMethod(
          contract.code,
          contract.storage || {},
          method,
          tx.args || {},
          {
            sender: tx.from,
            validator: validatorAddress,
            contractAddress: address,
          },
        );
        contracts[address] = {
          code: contract.code,
          storage: newStorage,
        };
        break;
      }
      case 'transfer':
      default:
        // For now transfers don't affect global chain state; wallets handle balances locally.
        break;
    }
  }

  return { stakes, contracts };
}

function runContractMethod(code, storage, method, args, ctx) {
  const sandbox = {
    module: { exports: {} },
    exports: {},
    console: {
      log: () => {},
      error: () => {},
    },
  };

  const context = vm.createContext(sandbox);
  const script = new vm.Script(code);
  script.runInContext(context);

  const contract = sandbox.module.exports || sandbox.exports;
  if (!contract || typeof contract[method] !== 'function') {
    // If method is missing, just return storage unchanged for init,
    // otherwise treat as error.
    if (method === 'init') return storage;
    throw new Error(`Contract method not found: ${method}`);
  }

  const newStorage = { ...(storage || {}) };
  contract[method](newStorage, args || {}, ctx || {});
  return newStorage;
}

module.exports = {
  Block,
  Blockchain,
};


