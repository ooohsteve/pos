const { v4: uuidv4 } = require('uuid');

class Wallet {
  constructor(initialBalance = 100) {
    this.address = uuidv4();
    this.balance = initialBalance;
    this.staked = 0;
  }

  canSpend(amount) {
    return amount > 0 && amount <= this.balance;
  }

  canStake(amount) {
    return amount > 0 && amount <= this.balance;
  }

  createTransaction(to, amount) {
    if (!this.canSpend(amount)) {
      throw new Error('Insufficient balance');
    }
    this.balance -= amount;
    return {
      from: this.address,
      to,
      amount,
      type: 'transfer',
      timestamp: Date.now(),
    };
  }

  createStake(amount) {
    if (!this.canStake(amount)) {
      throw new Error('Insufficient balance to stake');
    }
    this.balance -= amount;
    this.staked += amount;
    return {
      from: this.address,
      amount,
      type: 'stake',
      timestamp: Date.now(),
    };
  }

  applyBlock(block) {
    const { transactions } = block.data;
    for (const tx of transactions) {
      if (tx.type === 'transfer') {
        if (tx.to === this.address) {
          this.balance += tx.amount;
        }
        if (tx.from === this.address) {
          // already deducted locally, ignore
        }
      } else if (tx.type === 'stake' && tx.from === this.address) {
        this.staked += tx.amount;
      }
    }
  }
}

module.exports = { Wallet };


