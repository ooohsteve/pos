const WebSocket = require('ws');

const MESSAGE_TYPES = {
  CHAIN: 'CHAIN',
  NEW_BLOCK: 'NEW_BLOCK',
  TRANSACTION: 'TRANSACTION',
  STAKE: 'STAKE',
  REQUEST_CHAIN: 'REQUEST_CHAIN',
};

class P2PNetwork {
  constructor(blockchain, wallet, p2pPort, peers) {
    this.blockchain = blockchain;
    this.wallet = wallet;
    this.p2pPort = p2pPort;
    this.peers = peers;
    this.sockets = [];
  }

  start() {
    const server = new WebSocket.Server({ port: this.p2pPort });
    server.on('connection', (socket) => this.initConnection(socket));

    this.connectToPeers();
  }

  connectToPeers() {
    this.peers.forEach((peerUrl) => {
      const socket = new WebSocket(peerUrl);
      socket.on('open', () => this.initConnection(socket));
      socket.on('error', () => {});
    });
  }

  initConnection(socket) {
    this.sockets.push(socket);
    socket.on('message', (data) => this.handleMessage(socket, data));
    socket.on('close', () => {
      this.sockets = this.sockets.filter((s) => s !== socket);
    });
    this.send(socket, { type: MESSAGE_TYPES.CHAIN, data: this.blockchain.chain });
  }

  broadcast(message) {
    this.sockets.forEach((socket) => this.send(socket, message));
  }

  send(socket, message) {
    try {
      socket.send(JSON.stringify(message));
    } catch (e) {
      // ignore
    }
  }

  handleMessage(socket, rawData) {
    let msg;
    try {
      msg = JSON.parse(rawData);
    } catch {
      return;
    }
    const { type, data } = msg;
    switch (type) {
      case MESSAGE_TYPES.CHAIN: {
        this.blockchain.replaceChain(data);
        break;
      }
      case MESSAGE_TYPES.NEW_BLOCK: {
        const added = this.blockchain.addBlock(data);
        if (added) {
          this.wallet.applyBlock(data);
          this.broadcast({ type: MESSAGE_TYPES.CHAIN, data: this.blockchain.chain });
        }
        break;
      }
      case MESSAGE_TYPES.TRANSACTION: {
        this.blockchain.addTransaction(data);
        this.broadcast({ type: MESSAGE_TYPES.TRANSACTION, data });
        break;
      }
      case MESSAGE_TYPES.STAKE: {
        this.blockchain.addStake(data.from, data.amount);
        this.broadcast({ type: MESSAGE_TYPES.STAKE, data });
        break;
      }
      case MESSAGE_TYPES.REQUEST_CHAIN: {
        this.send(socket, { type: MESSAGE_TYPES.CHAIN, data: this.blockchain.chain });
        break;
      }
      default:
        break;
    }
  }
}

module.exports = {
  P2PNetwork,
  MESSAGE_TYPES,
};


