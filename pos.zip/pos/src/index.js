const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const { Blockchain } = require('./blockchain');
const { Wallet } = require('./wallet');
const { P2PNetwork } = require('./network');

const HTTP_PORT = process.env.HTTP_PORT || 3001;
const P2P_PORT = Number(process.env.P2P_PORT || 6001);
const PEERS = (process.env.PEERS || '')
  .split(',')
  .map((p) => p.trim())
  .filter((p) => p.length > 0);

const app = express();
app.use(bodyParser.json());

const blockchain = new Blockchain();
const wallet = new Wallet(100);
const network = new P2PNetwork(blockchain, wallet, P2P_PORT, PEERS);
network.start();

// HTTP API

app.get('/address', (req, res) => {
  res.json({ address: wallet.address });
});

app.get('/balance', (req, res) => {
  res.json({ balance: wallet.balance, staked: wallet.staked });
});

app.get('/chain', (req, res) => {
  res.json(blockchain.chain);
});

app.post('/transaction', (req, res) => {
  try {
    const { to, amount } = req.body;
    const tx = wallet.createTransaction(to, Number(amount));
    blockchain.addTransaction(tx);
    network.broadcast({ type: 'TRANSACTION', data: tx });
    res.json({ ok: true, tx });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.post('/stake', (req, res) => {
  try {
    const { amount } = req.body;
    const stakeTx = wallet.createStake(Number(amount));
    blockchain.addStake(wallet.address, stakeTx.amount);
    network.broadcast({ type: 'STAKE', data: { from: wallet.address, amount: stakeTx.amount } });
    res.json({ ok: true, stake: stakeTx, totalStake: blockchain.stakes });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.post('/produce-block', (req, res) => {
  const selected = blockchain.selectValidator();
  if (!selected) {
    return res.status(400).json({ error: 'No stakes in the system yet' });
  }
  if (selected !== wallet.address) {
    return res.status(403).json({ error: 'This node is not the current validator', selected });
  }
  const block = blockchain.createBlock(wallet.address);
  const added = blockchain.addBlock(block);
  if (!added) {
    return res.status(400).json({ error: 'Failed to add block' });
  }
  wallet.applyBlock(block);
  network.broadcast({ type: 'NEW_BLOCK', data: block });
  res.json({ ok: true, block });
});

// --- Smart contract endpoints ---

// Deploy a contract: body = { code: "module.exports = {...}", initArgs?: {...} }
app.post('/contract/deploy', (req, res) => {
  try {
    const { code, initArgs } = req.body;
    if (typeof code !== 'string' || code.trim().length === 0) {
      return res.status(400).json({ error: 'Contract code must be a non-empty string' });
    }

    const address = crypto
      .createHash('sha256')
      .update(`${wallet.address}:${Date.now()}:${code}`)
      .digest('hex')
      .slice(0, 40);

    const tx = {
      from: wallet.address,
      type: 'contract_deploy',
      code,
      initArgs: initArgs || {},
      address,
      timestamp: Date.now(),
    };

    blockchain.addTransaction(tx);
    network.broadcast({ type: 'TRANSACTION', data: tx });

    res.json({ ok: true, address, tx });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Call a contract method: body = { to, method, args?: {...} }
app.post('/contract/call', (req, res) => {
  try {
    const { to, method, args } = req.body;
    if (!to || !method) {
      return res.status(400).json({ error: 'Missing contract address or method' });
    }

    const tx = {
      from: wallet.address,
      to,
      method,
      args: args || {},
      type: 'contract_call',
      timestamp: Date.now(),
    };

    blockchain.addTransaction(tx);
    network.broadcast({ type: 'TRANSACTION', data: tx });

    res.json({ ok: true, tx });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Read current contract state (debug / read-only)
app.get('/contract/:address', (req, res) => {
  const state = blockchain.getContractState(req.params.address);
  if (!state) {
    return res.status(404).json({ error: 'Contract not found' });
  }
  res.json({ address: req.params.address, state });
});

app.listen(HTTP_PORT, () => {
  console.log(`HTTP server listening on port ${HTTP_PORT}`);
  console.log(`P2P port: ${P2P_PORT}`);
  console.log(`Peers: ${PEERS.join(', ') || 'none'}`);
  console.log(`Wallet address: ${wallet.address}`);
});


